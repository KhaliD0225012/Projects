import 'package:flutter/material.dart';
import 'package:flutter_application_1/main_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Mengubah warna background utama menjadi F5F9F7
      backgroundColor: const Color(0xFFF5F9F7),
      body: Stack(
        children: [
          // Aset sebagai latar belakang mentok di bawah dan tidak dipotong
          Align(
            alignment: Alignment.bottomCenter,
            child: Image.asset(
              'assets/background/background.png',
              width: double.infinity,
              fit: BoxFit.fitWidth,
            ),
          ),

          // Konten Utama Welcome Screen
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Spacer(),

                  // Judul Halaman
                  const Text(
                    "Semuanya siap!",
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF2D2D2D),
                      letterSpacing: -0.5,
                    ),
                  ),
                  const SizedBox(height: 32),

                  // Ikon Utama di Tengah
                  const Icon(
                    Icons.travel_explore,
                    size: 110,
                    color: Color(0xFF007979),
                  ),
                  const SizedBox(height: 32),

                  // Subjudul / Keterangan
                  const Text(
                    "Penjelajahan budayamu\nakan segera dimulai.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16,
                      color: Color(0xFF757575),
                      height: 1.5,
                    ),
                  ),

                  const Spacer(),
                  const SizedBox(height: 152), // Penyeimbang ruang di bagian bawah

                  // Tombol "Masuk ke Beranda"
                  Container(
                    width: double.infinity,
                    height: 56,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.06),
                          blurRadius: 0,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (context) => const MainScreen()),
                              (route) => false,
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF007979),
                        elevation: 0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                      child: const Text(
                        "Masuk ke Beranda",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}