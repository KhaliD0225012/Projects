import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'components.dart';
import 'login_screen.dart'; // Import halaman login

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool _isAgreed = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: const Icon(Icons.arrow_back_ios_new, size: 20, color: Color(0xFF2D2D2D)),
              ),
              const SizedBox(height: 24),

              const Text(
                "Buat akun baru",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900, // Dipertebal (Bold)
                  color: Color(0xFF2D2D2D),
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 8),

              const Text(
                "Yuk, bergabung dan mulai jelajahi\nbudaya Indonesia!",
                style: TextStyle(
                  fontSize: 17,
                  color: Color(0xFF555555), // Warna subtitle lebih gelap
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 24),

              const CustomTextField(
                label: "Nama Lengkap",
                hint: "Masukkan nama lengkap",
              ),

              const SizedBox(height: 20),

              const CustomTextField(
                label: "Email",
                hint: "contoh@email.com",
              ),

              const SizedBox(height: 20),

              const CustomTextField(
                label: "Kata Sandi",
                hint: "Minimal 8 karakter",
                isPassword: true,
              ),

              const SizedBox(height: 20),

              const CustomTextField(
                label: "Konfirmasi Kata Sandi",
                hint: "Masukkan ulang kata sandi",
                isPassword: true,
              ),

              const Spacer(),

              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                    height: 24,
                    width: 24,
                    child: Checkbox(
                      value: _isAgreed,
                      onChanged: (value) {
                        setState(() {
                          _isAgreed = value ?? false;
                        });
                      },
                      activeColor: const Color(0xFF007979),
                      shape: const CircleBorder(),
                      side: const BorderSide(color: Color(0xFFCCCCCC), width: 1.5),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text.rich(
                    TextSpan(
                      text: "Saya menyetujui ",
                      style: TextStyle(color: Color(0xFF555555), fontSize: 15), // Warna dibuat seragam
                      children: [
                        TextSpan(
                          text: "syarat & ketentuan",
                          style: TextStyle(
                            color: Color(0xFF555555), // Warna disamakan dengan teks sebelahnya
                            fontWeight: FontWeight.w900,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              const Spacer(),

              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.06),
                      blurRadius: 0,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    if (!_isAgreed) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Anda harus menyetujui syarat & ketentuan')),
                      );
                      return;
                    }

                    // Tampilkan pesan sukses registrasi
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Registrasi berhasil! Silakan masuk.')),
                    );

                    // Navigasi kembali ke LoginScreen dan hapus semua tumpukan halaman sebelumnya
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(builder: (context) => const LoginScreen()),
                          (route) => false,
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF007979),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  child: const Text(
                    "Daftar",
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 28),

              const DividerWithText(text: "atau daftar dengan"),

              const SizedBox(height: 28),

              const GoogleButton(),

              const SizedBox(height: 28),

              Center(
                child: Text.rich(
                  TextSpan(
                    text: "Sudah punya akun? ",
                    style: const TextStyle(color: Color(0xFF757575), fontSize: 16),
                    children: [
                      TextSpan(
                        text: "Masuk di sini",
                        style: const TextStyle(
                          color: Color(0xFF007979),
                          fontWeight: FontWeight.w900, // Dipertebal (Bold)
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            Navigator.pop(context);
                          },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}