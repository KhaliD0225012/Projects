import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'history_drawer.dart';
import 'notification_screen.dart';
import 'search_culture_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;
    final double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      drawer: const HistoryDrawer(),
      backgroundColor: const Color(0xFFFCF5EE),
      body: Stack(
        children: [
          // 1. Background Image dari assets/background/background.png
          Positioned(
            top: 1,
            child: Align(
              alignment: Alignment.topCenter,
              child: Image.asset(
                'assets/background/background.png',
                fit: BoxFit.fitWidth,
                alignment: Alignment.topCenter,
              ),
            ),
          ),

          // 2. Teks Header (Tetap di atas, tidak terpengaruh tumpukan bawah)
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header Ikon Atas
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Builder(
                        builder: (context) {
                          return GestureDetector(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.8),
                                border: Border.all(color: const Color(0xFFEAEAEA)),
                              ),
                              child: const Icon(Icons.history, color: Color(0xFF2D2D2D), size: 20),
                            ),
                          );
                        },
                      ),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const SearchCultureScreen()),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.8),
                                border: Border.all(color: const Color(0xFFEAEAEA)),
                              ),
                              child: const Icon(Icons.search, color: Color(0xFF2D2D2D), size: 20),
                            ),
                          ),
                          const SizedBox(width: 12),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const NotificationScreen()),
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(0.8),
                                border: Border.all(color: const Color(0xFFEAEAEA)),
                              ),
                              child: const Icon(Icons.notifications_none, color: Color(0xFF2D2D2D), size: 20),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    "Selamat datang, Budi!",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF2D2D2D),
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    "Kenali budaya Indonesia sebelum\nperjalananmu",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF2D2D2D),
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 3. Maskot (Fleksibel berdasarkan persentase lebar dan tinggi layar)
          Positioned(
            left: -screenWidth * 0.02,
            top: screenHeight * 0.23,
            width: screenWidth * 0.60,
            height: screenHeight * 0.33,
            child: Image.asset(
              'assets/maskot/mascot_mandar.png',
              fit: BoxFit.contain,
            ),
          ),

          // 4. Bubble Chat & Teks Penjelajahan
          Positioned(
            left: screenWidth * 0.52,
            right: 24,
            top: screenHeight * 0.28,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Gelembung Chat (Opsional: Tetap aktif atau diarahkan ke tempat lain jika diperlukan)
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ChatScreen()),
                    );
                  },
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(0),
                        topRight: Radius.circular(16),
                        bottomLeft: Radius.circular(16),
                        bottomRight: Radius.circular(16),
                      ),
                      border: Border.all(color: const Color(0xFFEAEAEA)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.06),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: const Text(
                      "Hai! Aku Taru, pemandu budaya digitalmu. Aku akan membantumu mengenal cerita, aturan, dan pengalaman menarik dari berbagai destinasi budaya",
                      style: TextStyle(
                        fontSize: 13,
                        color: Color(0xFF2D2D2D),
                        height: 1.35,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                // Teks "Lanjut penjelajahan" dibungkus GestureDetector agar menjadi satu-satunya jalur utama ke ChatScreen
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const ChatScreen()),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: const [
                      Text(
                        "Lanjut penjelajahan \nsebelumnya: --",
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                      Icon(Icons.chevron_right, size: 20, color: Color(0xFFFFFFFF)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // 5. Bottom Sheet: Jelajah Budaya
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: screenHeight * 0.40,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(24),
                  topRight: Radius.circular(24),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    offset: Offset(0, -4),
                  ),
                ],
              ),
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text(
                        "Jelajah Budaya",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF2D2D2D),
                        ),
                      ),
                      const SizedBox(width: 24),
                      Container(
                        width: 200,
                        height: 1.5,
                        color: const Color(0xFFE0E0E0),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Expanded(
                    child: GridView.count(
                      crossAxisCount: 4,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: 0.8,
                      children: [
                        _buildCultureItem("Bali", "assets/jelajah/jel_bali.png"),
                        _buildCultureItem("Jawa", "assets/jelajah/jel_jawa.png"),
                        _buildCultureItem("Batak", "assets/jelajah/jel_batak.png"),
                        _buildCultureItem("Padang", "assets/jelajah/jel_padang.png"),
                        _buildCultureItem("Bugis", "assets/jelajah/jel_bugis.png"),
                        _buildCultureItem("Papua", "assets/jelajah/jel_papua.png"),
                        _buildCultureItem("Dayak", "assets/jelajah/jel_dayak.png"),
                        _buildCultureItem("Lainnya", "assets/jelajah/jel_lainnya.png"),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Fungsi item budaya tanpa navigasi ke ChatScreen
  Widget _buildCultureItem(String name, String imagePath) {
    return Column(
      children: [
        Expanded(
          child: Center(
            child: Stack(
              clipBehavior: Clip.none,
              alignment: Alignment.center,
              children: [
                Container(
                  width: 72,
                  height: 81,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFEED0),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(
                        color: Color(0xFFD6D6D6),
                        offset: Offset(0, 2),
                        blurRadius: 0,
                        spreadRadius: 0,
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: -9,
                  left: -9,
                  right: -9,
                  bottom: -9,
                  child: SizedBox(
                    width: 88,
                    height: 94,
                    child: Image.asset(
                      imagePath,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          name,
          style: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: Color(0xFF2D2D2D),
          ),
        ),
      ],
    );
  }
}