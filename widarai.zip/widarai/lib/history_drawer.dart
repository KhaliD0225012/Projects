import 'package:flutter/material.dart';
import 'chat_bali_active_screen.dart';
import 'chat_screen.dart';
import 'login_screen.dart'; // Tambahkan import LoginScreen (atau WelcomeScreen)

class HistoryDrawer extends StatefulWidget {
  const HistoryDrawer({super.key});

  @override
  State<HistoryDrawer> createState() => _HistoryDrawerState();
}

class _HistoryDrawerState extends State<HistoryDrawer> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isSearching = false;
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  // Fungsi Dialog Konfirmasi Logout
  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text(
            "Konfirmasi Keluar",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2D2D2D),
            ),
          ),
          content: const Text(
            "Apakah Anda yakin ingin keluar dari akun ini?",
            style: TextStyle(
              fontSize: 14,
              color: Color(0xFF4A4A4A),
              fontWeight: FontWeight.w500,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text(
                "Batal",
                style: TextStyle(color: Color(0xFF6B6B6B), fontWeight: FontWeight.w600),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFD32F2F),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 0,
              ),
              onPressed: () {
                Navigator.of(context).pop(); // Tutup dialog
                // Navigasi balik ke LoginScreen & hapus semua tumpukan halaman sebelumnya
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                      (route) => false,
                );
              },
              child: const Text(
                "Keluar",
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFFFFFFFF),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.horizontal(
          right: Radius.zero,
        ),
      ),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Riwayat & Search Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 24, 24, 16),
              child: _isSearching
                  ? Container(
                height: 45,
                decoration: BoxDecoration(
                  color: Colors.grey.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFEAEAEA)),
                ),
                child: TextField(
                  controller: _searchController,
                  autofocus: true,
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value.toLowerCase();
                    });
                  },
                  style: const TextStyle(fontSize: 14, color: Color(0xFF2D2D2D)),
                  decoration: InputDecoration(
                    hintText: "Cari riwayat...",
                    hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
                    contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                    border: InputBorder.none,
                    suffixIcon: IconButton(
                      icon: const Icon(Icons.close, color: Color(0xFF2D2D2D), size: 18),
                      onPressed: () {
                        setState(() {
                          _isSearching = false;
                          _searchQuery = "";
                          _searchController.clear();
                        });
                      },
                    ),
                  ),
                ),
              )
                  : Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    "Riwayat",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2D2D2D),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.search, color: Color(0xFF007979)),
                    tooltip: "Cari Riwayat",
                    onPressed: () {
                      setState(() {
                        _isSearching = true;
                      });
                    },
                  ),
                ],
              ),
            ),

            // TabBar
            TabBar(
              controller: _tabController,
              labelColor: const Color(0xFF2D2D2D),
              unselectedLabelColor: Colors.grey,
              indicatorColor: const Color(0xFF007979),
              indicatorWeight: 3,
              labelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              tabs: const [
                Tab(text: "Chat"),
                Tab(text: "Artikel"),
              ],
            ),
            const SizedBox(height: 16),

            // Konten Riwayat Chat
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildChatHistory(),
                  const Center(child: Text("Belum ada riwayat artikel")),
                ],
              ),
            ),

            // Profil & Tombol Logout di Bawah
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: const Color(0xFFFFFFFF),
                border: Border(top: BorderSide(color: Colors.grey.shade300)),
              ),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 24,
                    backgroundImage: AssetImage('assets/riwayat/profil.png'),
                    backgroundColor: Color(0xFF007979),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          "Budi Santoso",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D)),
                        ),
                        GestureDetector(
                          onTap: () {},
                          child: const Text(
                            "Edit profil",
                            style: TextStyle(fontSize: 12, color: Colors.grey, decoration: TextDecoration.underline),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.logout, color: Colors.redAccent),
                    onPressed: () => _showLogoutDialog(context), // Panggil dialog logout di sini
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatHistory() {
    var todaysItems = [
      {"title": "Budaya Mandar", "subtitle": "Ada banyak keanekaragama..", "imagePath": "assets/riwayat/mandar.png"},
      {"title": "Budaya Padang", "subtitle": "Makanan dengan lauk yang..", "imagePath": "assets/riwayat/padang.png"},
      {"title": "Budaya Bali", "subtitle": "Pulau dewata yang memilik..", "imagePath": "assets/riwayat/bali.png"},
    ];

    var yesterdaysItems = [
      {"title": "Budaya Jawa", "subtitle": "Filosofi hidup dan kesopana..", "imagePath": "assets/riwayat/jawa.png"},
      {"title": "Budaya Sunda", "subtitle": "Keramahan dan keharmonis..", "imagePath": "assets/riwayat/sunda.png"},
      {"title": "Budaya Batak", "subtitle": "Ikatan marga menjadi dasar k..", "imagePath": "assets/riwayat/batak.png"},
    ];

    var filteredToday = todaysItems.where((item) =>
    item['title']!.toLowerCase().contains(_searchQuery) ||
        item['subtitle']!.toLowerCase().contains(_searchQuery)).toList();

    var filteredYesterday = yesterdaysItems.where((item) =>
    item['title']!.toLowerCase().contains(_searchQuery) ||
        item['subtitle']!.toLowerCase().contains(_searchQuery)).toList();

    if (_searchQuery.isNotEmpty && filteredToday.isEmpty && filteredYesterday.isEmpty) {
      return const Center(
        child: Text("Riwayat tidak ditemukan", style: TextStyle(color: Colors.grey)),
      );
    }

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      children: [
        if (filteredToday.isNotEmpty) ...[
          const Text("Hari ini", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D))),
          const SizedBox(height: 12),
          for (var item in filteredToday)
            _buildHistoryItem(title: item['title']!, subtitle: item['subtitle']!, imagePath: item['imagePath']!),
        ],
        if (filteredYesterday.isNotEmpty) ...[
          const SizedBox(height: 24),
          const Text("Kemarin", style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D))),
          const SizedBox(height: 12),
          for (var item in filteredYesterday)
            _buildHistoryItem(title: item['title']!, subtitle: item['subtitle']!, imagePath: item['imagePath']!),
        ],
      ],
    );
  }

  Widget _buildHistoryItem({required String title, required String subtitle, required String imagePath}) {
    return GestureDetector(
      onTap: () {
        if (title == "Budaya Bali") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ChatBaliActiveScreen()),
          );
        } else if (title == "Budaya Mandar") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ChatScreen()),
          );
        }
      },
      behavior: HitTestBehavior.opaque,
      child: Padding(
        padding: const EdgeInsets.only(bottom: 16.0),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey.shade300,
                image: DecorationImage(
                  image: AssetImage(imagePath),
                  fit: BoxFit.cover,
                  onError: (exception, stackTrace) {},
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D)),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}