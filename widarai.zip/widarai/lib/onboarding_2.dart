import 'package:flutter/material.dart';

class Onboarding2 extends StatelessWidget {
  const Onboarding2({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
      child: Column(
        children: [
          const SizedBox(height: 80),
          const SizedBox(
            width: 300,
            child: Text(
              "Kenali budaya dengan\ncara yang lebih seru!",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D), height: 1.2, letterSpacing: -0.5),
            ),
          ),
          const SizedBox(height: 24),
          Container(width: 72, height: 2, color: const Color(0xFF007979).withOpacity(0.4)),
          const SizedBox(height: 24),

          Expanded(
            child: Align(
              alignment: const Alignment(0.25, -0.75),
              child: SizedBox(
                width: 325,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildFeatureItem(icon: Icons.chat_bubble_outline, text: "Chat & Berbicara dengan\ntokoh hewan"),
                    const SizedBox(height: 62),
                    _buildFeatureItem(icon: Icons.article_outlined, text: "Baca artikel terpercaya\ntentang budaya"),
                    const SizedBox(height: 62),
                    _buildFeatureItem(icon: Icons.favorite_border, text: "Simpan favorit untuk\nbudaya yang kamu suka"),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeatureItem({required IconData icon, required String text}) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xFF007979)),
          child: Icon(icon, color: Colors.white, size: 24),
        ),
        const SizedBox(width: 24),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.normal, color: Color(0xFF2D2D2D), height: 1.3),
          ),
        ),
      ],
    );
  }
}