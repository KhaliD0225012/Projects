import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'chat_bali_screen.dart';
import 'map_culture_screen.dart';

class CultureItem {
  final String title;
  final String subtitle;
  final String region;
  final String imagePath;

  CultureItem({
    required this.title,
    required this.subtitle,
    required this.region,
    required this.imagePath,
  });
}

class SearchCultureScreen extends StatefulWidget {
  const SearchCultureScreen({super.key});

  @override
  State<SearchCultureScreen> createState() => _SearchCultureScreenState();
}

class _SearchCultureScreenState extends State<SearchCultureScreen> {
  String _searchQuery = '';
  String _selectedCategory = 'Semua';

  final List<CultureItem> _allCultures = [
    CultureItem(
      title: "Budaya Toraja",
      subtitle: "Penghormatan kepada leluhur menjadi bagian penting kehidupan masyarakat.",
      region: "Sulawesi",
      imagePath: 'assets/images/toraja.png',
    ),
    CultureItem(
      title: "Budaya Padang",
      subtitle: "Filosofi adat dan hubungan kekerabatan menjadi ciri masyarakat padang.",
      region: "Sumatera",
      imagePath: 'assets/riwayat/padang.png',
    ),
    CultureItem(
      title: "Budaya Bali",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Bali",
      imagePath: 'assets/riwayat/bali.png',
    ),
    CultureItem(
      title: "Budaya Mandar",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Sulawesi",
      imagePath: 'assets/riwayat/mandar.png',
    ),
    CultureItem(
      title: "Budaya Jawa",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Pulau Jawa",
      imagePath: 'assets/riwayat/jawa.png',
    ),
    CultureItem(
      title: "Budaya Betawi",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Pulau Jawa",
      imagePath: 'assets/images/betawi.png',
    ),
    CultureItem(
      title: "Budaya Dayak",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Kalimantan",
      imagePath: 'assets/images/dayak.png',
    ),
    CultureItem(
      title: "Budaya Batak",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Sumatera",
      imagePath: 'assets/riwayat/batak.png',
    ),
    CultureItem(
      title: "Budaya Sunda",
      subtitle: "Pulau Dewata dengan seni dan spiritualitas yang mendalam.",
      region: "Pulau Jawa",
      imagePath: 'assets/riwayat/sunda.png',
    ),
  ];

  final List<String> _categories = ['Semua', 'Pulau Jawa', 'Sumatera', 'Sulawesi', 'Kalimantan', 'Bali'];

  @override
  Widget build(BuildContext context) {
    final filteredCultures = _allCultures.where((culture) {
      final matchesSearch = culture.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          culture.subtitle.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'Semua' || culture.region == _selectedCategory;
      return matchesSearch && matchesCategory;
    }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Pilih Budaya",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2D2D2D),
          ),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      // Search Bar dengan tinggi eksplisit 48
                      Expanded(
                        child: SizedBox(
                          height: 48,
                          child: TextField(
                            onChanged: (value) {
                              setState(() {
                                _searchQuery = value;
                              });
                            },
                            decoration: InputDecoration(
                              hintText: "Cari budaya..",
                              hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
                              prefixIcon: const Icon(Icons.search, color: Colors.grey),
                              filled: true,
                              fillColor: Colors.white,
                              contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide: const BorderSide(color: Color(0xFFEAEAEA)),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide: const BorderSide(color: Color(0xFFEAEAEA)),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(30),
                                borderSide: const BorderSide(color: Color(0xFF007979)),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),

                      // Tombol Peta dengan tinggi 48 & Icon Icons.travel_explore
                      SizedBox(
                        height: 48,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const MapCultureScreen()),
                            );
                          },
                          borderRadius: BorderRadius.circular(30),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(30),
                              border: Border.all(color: const Color(0xFFEAEAEA)),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: const [
                                Icon(
                                  Icons.travel_explore, // Ikon baru: travel_explore
                                  color: Color(0xFF007979),
                                  size: 20,
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "Peta",
                                  style: TextStyle(
                                    color: Color(0xFF007979),
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _categories.length,
                      itemBuilder: (context, index) {
                        final category = _categories[index];
                        final isSelected = _selectedCategory == category;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: ChoiceChip(
                            label: Text(category),
                            selected: isSelected,
                            onSelected: (selected) {
                              setState(() {
                                _selectedCategory = category;
                              });
                            },
                            backgroundColor: Colors.white,
                            selectedColor: const Color(0xFF007979),
                            labelStyle: TextStyle(
                              color: isSelected ? Colors.white : const Color(0xFF2D2D2D),
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(
                                color: isSelected ? const Color(0xFF007979) : const Color(0xFFEAEAEA),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final culture = filteredCultures[index];
                  return Column(
                    children: [
                      GestureDetector(
                        onTap: () {
                          if (culture.title == "Budaya Mandar") {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatScreen()),
                            );
                          } else if (culture.title == "Budaya Bali") {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatBaliScreen()),
                            );
                          }
                        },
                        behavior: HitTestBehavior.opaque,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(vertical: 12.0),
                          child: Row(
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: SizedBox(
                                  width: 56,
                                  height: 56,
                                  child: Image.asset(
                                    culture.imagePath,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) => Container(
                                      color: Colors.grey.shade200,
                                      child: const Icon(Icons.image, color: Colors.grey),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      culture.title,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF2D2D2D),
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      culture.subtitle,
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                        height: 1.3,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              const Icon(Icons.chevron_right, color: Colors.grey),
                            ],
                          ),
                        ),
                      ),
                      if (index < filteredCultures.length - 1)
                        const Divider(height: 1, color: Color(0xFFEAEAEA)),
                    ],
                  );
                },
                childCount: filteredCultures.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}