import 'package:flutter/material.dart';
import 'ngaben_detail_screen.dart';
import 'sayyang_pattudu_detail_screen.dart';

class ArticleItem {
  final String title;
  final String subtitle;
  final String region;
  final String imagePath;

  ArticleItem({
    required this.title,
    required this.subtitle,
    required this.region,
    required this.imagePath,
  });
}

class ArticleScreen extends StatefulWidget {
  const ArticleScreen({super.key});

  @override
  State<ArticleScreen> createState() => _ArticleScreenState();
}

class _ArticleScreenState extends State<ArticleScreen> {
  String _searchQuery = '';
  String _selectedCategory = 'Semua';

  final List<String> _categories = ['Semua', 'Pulau Jawa', 'Sumatera', 'Sulawesi', 'Bali', 'Papua'];

  final List<ArticleItem> _allArticles = [
    ArticleItem(
      title: "Mengenal Ngaben Bali, Lebih dari Sekadar Upacara Kremasi",
      subtitle: "Budaya Bali • detikNews",
      region: "Bali",
      imagePath: 'assets/artikel/ngaben.png',
    ),
    ArticleItem(
      title: "Sayyang Pattudu, Pesona Kuda Menari dari Tanah Mandar",
      subtitle: "Budaya Mandar • CNN Indonesia",
      region: "Sulawesi",
      imagePath: 'assets/artikel/pattudu.png',
    ),
    ArticleItem(
      title: "Dari Ranah Minang ke Meja Makan, Inilah Kisah Masakan Padang",
      subtitle: "Budaya Padang • Kompas Media",
      region: "Sumatera",
      imagePath: 'assets/artikel/minang.png',
    ),
    ArticleItem(
      title: "Tifa Papua, Irama dari Budaya Tanah Timur",
      subtitle: "Budaya Papua • Pesona Indonesia",
      region: "Papua",
      imagePath: 'assets/artikel/tifa.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final filteredArticles = _allArticles.where((article) {
      final matchesSearch = article.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          article.subtitle.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesCategory = _selectedCategory == 'Semua' || article.region == _selectedCategory;
      return matchesSearch && matchesCategory;
    }).toList();

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        automaticallyImplyLeading: false,
        title: const Padding(
          padding: EdgeInsets.only(left: 8.0, top: 8.0),
          child: Text(
            "Artikel",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF2D2D2D),
            ),
          ),
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
              child: Column(
                children: [
                  TextField(
                    onChanged: (value) {
                      setState(() {
                        _searchQuery = value;
                      });
                    },
                    decoration: InputDecoration(
                      hintText: "Cari artikel...",
                      hintStyle: const TextStyle(color: Colors.grey, fontSize: 14),
                      prefixIcon: const Icon(Icons.search, color: Colors.grey),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: const BorderSide(color: Color(0xFFEAEAEA)),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: const BorderSide(color: Color(0xFFEAEAEA)),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: const BorderSide(color: Color(0xFF007979)),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    height: 40,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _categories.length,
                      itemBuilder: (context, index) {
                        final category = _categories[index];
                        final isSelected = _selectedCategory == category;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8.0),
                          child: ChoiceChip(
                            label: Text(category),
                            selected: isSelected,
                            onSelected: (selected) {
                              setState(() {
                                _selectedCategory = category;
                              });
                            },
                            backgroundColor: Colors.white,
                            selectedColor: const Color(0xFF007979),
                            labelStyle: TextStyle(
                              color: isSelected ? Colors.white : const Color(0xFF2D2D2D),
                              fontWeight: FontWeight.w600,
                              fontSize: 13,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              side: BorderSide(
                                color: isSelected ? const Color(0xFF007979) : const Color(0xFFEAEAEA),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            sliver: SliverList(
              delegate: SliverChildBuilderDelegate(
                    (context, index) {
                  final article = filteredArticles[index];
                  return GestureDetector(
                    onTap: () {
                      if (article.title.contains("Ngaben")) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const NgabenDetailScreen()),
                        );
                      } else if (article.title.contains("Sayyang Pattudu")) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const SayyangPattuduDetailScreen()),
                        );
                      }
                    },
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ClipRRect(
                                borderRadius: BorderRadius.circular(16),
                                child: SizedBox(
                                  height: 180,
                                  width: double.infinity,
                                  child: Image.asset(
                                    article.imagePath,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) => Container(
                                      color: Colors.grey.shade200,
                                      child: const Icon(Icons.image, size: 50, color: Colors.grey),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                article.title,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF2D2D2D),
                                  height: 1.3,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                article.subtitle,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (index < filteredArticles.length - 1)
                          const Divider(height: 24, thickness: 1, color: Color(0xFFEAD8C8)),
                      ],
                    ),
                  );
                },
                childCount: filteredArticles.length,
              ),
            ),
          ),
          const SliverToBoxAdapter(
            child: SizedBox(height: 24),
          ),
        ],
      ),
    );
  }
}