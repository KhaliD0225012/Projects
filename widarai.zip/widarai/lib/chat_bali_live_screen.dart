import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class ChatBaliLiveScreen extends StatefulWidget {
  const ChatBaliLiveScreen({super.key});

  @override
  State<ChatBaliLiveScreen> createState() => _ChatBaliLiveScreenState();
}

class _ChatBaliLiveScreenState extends State<ChatBaliLiveScreen> with SingleTickerProviderStateMixin {
  bool _isLiked = false;
  bool _isRecording = false;
  late AnimationController _pulseController;
  Timer? _waveformTimer;
  late List<double> _waveformHeights;

  @override
  void initState() {
    super.initState();
    // Inisialisasi animasi lingkaran berlapis
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();

    // Tinggi awal batang suara (pendek/diam)
    _waveformHeights = List.filled(15, 6.0);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _waveformTimer?.cancel();
    super.dispose();
  }

  void _startRecording() {
    setState(() {
      _isRecording = true;
    });
    // Mulai animasi pergerakan batang suara saat ditahan
    _waveformTimer = Timer.periodic(const Duration(milliseconds: 150), (timer) {
      setState(() {
        _waveformHeights = List.generate(15, (index) => Random().nextInt(26).toDouble() + 6);
      });
    });
  }

  void _stopRecording() {
    _waveformTimer?.cancel();
    setState(() {
      _isRecording = false;
      _waveformHeights = List.filled(15, 6.0); // Kembali diam
    });
  }

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80.0),
        child: AppBar(
          backgroundColor: const Color(0xFFFFFBF6),
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80.0,
          titleSpacing: 0,
          leading: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 18, color: Colors.black87),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  "Budaya Bali", // Diubah menjadi Budaya Bali
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.black87),
                ),
                SizedBox(height: 2),
                Text(
                  "Pulau dewata yang memiliki b..", // Disesuaikan dengan app bar chat bali sebelumnya
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(top: 12.0, right: 8.0),
              child: IconButton(
                icon: Icon(
                  _isLiked ? Icons.favorite : Icons.favorite_border,
                  color: Colors.red,
                  size: 24,
                ),
                onPressed: () {
                  setState(() {
                    _isLiked = !_isLiked;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(_isLiked ? "Ditambahkan ke favorit!" : "Dihapus dari favorit"),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // 1. Gambar Background (Tinggi 43% layar) dengan efek pudar hanya di bagian bawah
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: screenHeight * 0.43,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/background/chat_background_2.jpg', // Diubah menjadi chat_background_2.jpg
                  fit: BoxFit.fitWidth,
                  alignment: Alignment.bottomCenter,
                ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFFFCF5EE).withOpacity(0.0),
                        const Color(0xFFFCF5EE),
                      ],
                      stops: const [0.75, 1.0],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Gelembung Percakapan Bot
          Positioned(
            top: 205,
            left: 195,
            child: SizedBox(
              width: 180,
              child: Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(0),
                    topRight: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(16),
                  ),
                  border: Border.all(color: const Color(0xFFEAEAEA)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: const Text(
                  "Ogoh-ogoh adalah patung besar yang melambangkan sifat negatif dan diarak menjelang Hari Raya Nyepi.", // Teks bubble diubah
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                    height: 1.4,
                  ),
                ),
              ),
            ),
          ),

          // 3. Kotak Teks Pertanyaan (Posisi 3/7 Layar)
          Positioned(
            top: screenHeight * (3 / 7),
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 310,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        "Apa nama patung besar yang biasanya diarak menjelang Hari Raya Nyepi?", // Teks pertanyaan diubah
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF757575),
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // 4. Batang-batang Suara (Waveform) di antara teks dan tombol mic
          Positioned(
            top: screenHeight * (4.3 / 7),
            left: 40,
            right: 40,
            child: SizedBox(
              height: 36,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: _waveformHeights.map((h) => _buildWaveBar(h)).toList(),
              ),
            ),
          ),

          // 5. Bagian Tombol Mic di Posisi 5/7 Layar & Keterangan di Bawahnya
          Positioned(
            top: screenHeight * (5 / 7),
            left: 0,
            right: 0,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Tombol Mikrofon dengan Efek Lingkaran Berlapis & Luas
                Center(
                  child: SizedBox(
                    width: 140,
                    height: 140,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        if (_isRecording) ...[
                          // Lingkaran Gelombang Luas Lapisan 1
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              final value = _pulseController.value;
                              return Container(
                                width: 56 + (value * 80),
                                height: 56 + (value * 80),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0xFF007979).withOpacity(1.0 - value),
                                ),
                              );
                            },
                          ),
                          // Lingkaran Gelombang Luas Lapisan 2 (Delay Fasa)
                          AnimatedBuilder(
                            animation: _pulseController,
                            builder: (context, child) {
                              final value = (_pulseController.value + 0.5) % 1.0;
                              return Container(
                                width: 56 + (value * 80),
                                height: 56 + (value * 80),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: const Color(0xFF007979).withOpacity(1.0 - value),
                                ),
                              );
                            },
                          ),
                        ],
                        // Tombol Utama Mikrofon
                        GestureDetector(
                          onTapDown: (_) => _startRecording(),
                          onTapUp: (_) => _stopRecording(),
                          onTapCancel: () => _stopRecording(),
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF007979),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 6,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.mic,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                // Keterangan teks di bawah tombol mic
                Text(
                  _isRecording ? "Merekam suara..." : "Tahan untuk berbicara",
                  style: const TextStyle(
                    fontSize: 15,
                    color: Color(0xFF757575),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Widget pembantu untuk membuat batang gelombang suara (waveform bar)
  Widget _buildWaveBar(double height) {
    return Container(
      width: 3,
      height: height,
      decoration: BoxDecoration(
        color: const Color(0xFF007979),
        borderRadius: BorderRadius.circular(1.5),
      ),
    );
  }
}