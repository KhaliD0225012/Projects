import 'package:flutter/material.dart';
import 'chat_bali_active_screen.dart'; // Import halaman chat aktif

class ChatBaliScreen extends StatefulWidget {
  const ChatBaliScreen({super.key});

  @override
  State<ChatBaliScreen> createState() => _ChatBaliScreenState();
}

class _ChatBaliScreenState extends State<ChatBaliScreen> {
  bool _isLiked = false;

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80.0),
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80.0,
          titleSpacing: 0,
          leading: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 18, color: Colors.black87),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  "Budaya Bali",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.black87),
                ),
                SizedBox(height: 2),
                Text(
                  "Pulau dewata yang memiliki b..",
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(top: 12.0, right: 8.0),
              child: IconButton(
                icon: Icon(
                  _isLiked ? Icons.favorite : Icons.favorite_border,
                  color: Colors.red,
                  size: 24,
                ),
                onPressed: () {
                  setState(() {
                    _isLiked = !_isLiked;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(_isLiked ? "Ditambahkan ke favorit!" : "Dihapus dari favorit"),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // 1. Gambar Background (Tinggi 2/5 layar = 40%)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: screenHeight * 0.4,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/background/chat_background_2.jpg',
                  fit: BoxFit.fitWidth,
                  alignment: Alignment.bottomCenter,
                ),
                // Efek Pudar ke bawah
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFFFCF5EE).withOpacity(0.0),
                        const Color(0xFFFCF5EE),
                      ],
                      stops: const [0.3, 1.0],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Area Pesan Awal (Teks Sapaan) dan Input Bar
          Column(
            children: [
              Expanded(
                child: ShaderMask(
                  shaderCallback: (Rect bounds) {
                    return const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black, Colors.black],
                      stops: [0.0, 0.48, 1.0],
                    ).createShader(bounds);
                  },
                  blendMode: BlendMode.dstIn,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    children: [
                      SizedBox(height: screenHeight * 0.45),

                      // Teks Sapaan Awal
                      const Text(
                        "Halo! Aku Cici. Ayo mulai\nbicarakan tentang\nbudaya Bali.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          color: Color(0xFF4A4A4A),
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 40),

                      // Ikon Panah Ke Bawah
                      const Icon(
                        Icons.arrow_downward,
                        color: Color(0xFFD3D3D3),
                        size: 32,
                      ),

                      const SizedBox(height: 40),
                    ],
                  ),
                ),
              ),

              // Bar Input Chat di Bawah
              Container(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                color: const Color(0xFFFCF5EE),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildChip(context, "Apa saja lagu daerah Bali?"),
                          const SizedBox(width: 8),
                          _buildChip(context, "Bagaimana cara orang..."),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(color: const Color(0xFFEAEAEA)),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.03),
                                  blurRadius: 5,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: TextField(
                                    readOnly: true, // Mencegah keyboard muncul
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (context) => const ChatBaliActiveScreen()),
                                      );
                                    },
                                    style: const TextStyle(fontSize: 16),
                                    decoration: const InputDecoration(
                                      hintText: "Ketik pesan..",
                                      border: InputBorder.none,
                                      hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
                                    ),
                                  ),
                                ),
                                const Icon(Icons.mic_none, color: Colors.grey, size: 24),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatBaliActiveScreen()),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF007979),
                            ),
                            child: const Icon(Icons.graphic_eq, color: Colors.white, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChip(BuildContext context, String label) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ChatBaliActiveScreen()),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: const Color(0xFFEAEAEA)),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
      ),
    );
  }
}