import 'package:flutter/material.dart';

class NotificationModel {
  final String title;
  final String subtitle;
  final String? imagePath;
  bool isNew;

  NotificationModel({
    required this.title,
    required this.subtitle,
    this.imagePath,
    this.isNew = false,
  });
}

class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  bool _isSelectionMode = false;

  // Daftar data notifikasi agar bisa dikelola/dihapus
  final List<NotificationModel> _notifications = [
    NotificationModel(
      title: "⛵ Secepat Apa Perahu Sandeq?",
      subtitle: "Temukan kisah pelaut Mandar di balik perahu legendaris ini!",
      imagePath: 'assets/images/sandeq.png',
      isNew: true,
    ),
    NotificationModel(
      title: "⭐ Kamu udah tau Tongkonan belum?",
      subtitle: "Yuk, cari tau makna rumah adat yang menjadi simbol masyarakat Toraja!",
    ),
    NotificationModel(
      title: "📚 Saatnya menjelajahi budaya baru!",
      subtitle: "Ayo jelajahi dan dapatkan hingga 1000 XP.",
    ),
  ];

  // Menyimpan indeks kartu yang dipilih
  final Set<int> _selectedIndices = {};

  void _toggleSelectionMode() {
    setState(() {
      _isSelectionMode = !_isSelectionMode;
      _selectedIndices.clear();
    });
  }

  void _toggleSelectAll() {
    setState(() {
      if (_selectedIndices.length == _notifications.length) {
        _selectedIndices.clear();
      } else {
        _selectedIndices.addAll(List.generate(_notifications.length, (index) => index));
      }
    });
  }

  void _deleteSelected() {
    setState(() {
      // Urutkan dari indeks terbesar ke terkecil agar tidak terjadi pergeseran indeks saat dihapus
      final sortedIndices = _selectedIndices.toList()..sort((a, b) => b.compareTo(a));
      for (var index in sortedIndices) {
        _notifications.removeAt(index);
      }
      _selectedIndices.clear();
      _isSelectionMode = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE), // Warna background utama aplikasi
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87),
          onPressed: () {
            if (_isSelectionMode) {
              _toggleSelectionMode();
            } else {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          _isSelectionMode ? "${_selectedIndices.length} Dipilih" : "Notifikasi",
          style: const TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2D2D2D),
          ),
        ),
        centerTitle: false,
        actions: [
          if (_isSelectionMode) ...[
            // Tombol Pilih Semua
            IconButton(
              icon: const Icon(Icons.select_all, color: Colors.black87),
              onPressed: _toggleSelectAll,
              tooltip: "Pilih Semua",
            ),
            // Tombol Hapus item yang dipilih
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: _selectedIndices.isEmpty ? null : _deleteSelected,
              tooltip: "Hapus Terpilih",
            ),
          ] else ...[
            // Tombol untuk mengaktifkan mode pemilihan/penghapusan
            IconButton(
              icon: const Icon(Icons.delete_sweep_outlined, color: Colors.black87, size: 28),
              onPressed: _toggleSelectionMode,
              tooltip: "Pilih untuk Hapus",
            ),
          ],
          const SizedBox(width: 8),
        ],
      ),
      body: _notifications.isEmpty
          ? const Center(
        child: Text(
          "Tidak ada notifikasi",
          style: TextStyle(color: Colors.grey, fontSize: 16),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          final item = _notifications[index];
          final isSelected = _selectedIndices.contains(index);

          return GestureDetector(
            onTap: () {
              if (_isSelectionMode) {
                setState(() {
                  if (isSelected) {
                    _selectedIndices.remove(index);
                  } else {
                    _selectedIndices.add(index);
                  }
                });
              }
            },
            child: Container(
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFFF2E6DC) : const Color(0xFFFDF8F5), // Berubah warna saat dipilih
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isSelected ? const Color(0xFF007979) : const Color(0xFFEAD8C8),
                  width: isSelected ? 2.0 : 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 0,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Tampilkan Checkbox jika dalam mode seleksi
                        if (_isSelectionMode) ...[
                          Checkbox(
                            value: isSelected,
                            activeColor: const Color(0xFF007979),
                            onChanged: (bool? value) {
                              setState(() {
                                if (value == true) {
                                  _selectedIndices.add(index);
                                } else {
                                  _selectedIndices.remove(index);
                                }
                              });
                            },
                          ),
                          const SizedBox(width: 8),
                        ],

                        // Jika ada gambar dan tidak dalam mode seleksi, tampilkan gambar di kiri
                        if (item.imagePath != null && !_isSelectionMode) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Container(
                              width: 64,
                              height: 64,
                              color: Colors.grey.shade300,
                              child: Image.asset(
                                item.imagePath!,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                const Icon(Icons.image, color: Colors.grey),
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                        ],

                        // Teks Judul dan Subjudul
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                style: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                  color: Color(0xFF2D2D2D),
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                item.subtitle,
                                style: const TextStyle(
                                  fontSize: 13,
                                  color: Color(0xFF757575),
                                  height: 1.4,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Label "BARU" di pojok kanan atas (hanya jika bukan mode seleksi)
                  if (item.isNew && !_isSelectionMode)
                    Positioned(
                      top: 0,
                      right: 0,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                        decoration: const BoxDecoration(
                          color: Color(0xFFF04A41),
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(14),
                            bottomLeft: Radius.circular(12),
                          ),
                        ),
                        child: const Text(
                          "BARU",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}