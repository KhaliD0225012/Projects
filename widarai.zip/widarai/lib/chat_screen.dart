import 'package:flutter/material.dart';
import 'chat_live_screen.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  bool _isLiked = false;

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80.0),
        child: AppBar(
          backgroundColor: Color(0xFFFFFBF6),
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80.0,
          titleSpacing: 0,
          leading: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 18, color: Colors.black87),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  "Budaya Mandar",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.black87),
                ),
                SizedBox(height: 2),
                Text(
                  "Ada banyak keanekaragaman d..",
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(top: 12.0, right: 8.0),
              child: IconButton(
                icon: Icon(
                  _isLiked ? Icons.favorite : Icons.favorite_border,
                  color: Colors.red,
                  size: 24,
                ),
                onPressed: () {
                  setState(() {
                    _isLiked = !_isLiked;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(_isLiked ? "Ditambahkan ke favorit!" : "Dihapus dari favorit"),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // 1. Gambar Background (Tinggi 2/5 layar = 40%)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: screenHeight * 0.4,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/background/chat_background_1.jpg',
                  fit: BoxFit.fitWidth,
                  alignment: Alignment.bottomCenter,
                ),
                // Efek Pudar ke bawah
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFFFCF5EE).withOpacity(0.0),
                        const Color(0xFFFCF5EE),
                      ],
                      stops: const [0.3, 1.0],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Daftar Pesan Chat dan Input Bar
          Column(
            children: [
              Expanded(
                child: ShaderMask(
                  shaderCallback: (Rect bounds) {
                    return const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black, Colors.black],
                      stops: [0.0, 0.48, 1.0],
                    ).createShader(bounds);
                  },
                  blendMode: BlendMode.dstIn,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    children: [
                      const SizedBox(height: 140),

                      _buildBotMessage(
                        "Pertanyaan yang bagus! Jadi, Suku Mandar berasal dari Provinsi Sulawesi Barat, Indonesia, khususnya wilayah Polewali Mandar.",
                        "16:37",
                        isFirst: true,
                      ),

                      _buildUserMessage(
                        "Apa yang perlu saya ketahui sebelum mengunjungi budaya Mandar?",
                        "16:39",
                      ),

                      _buildBotMessage(
                        "Budaya Mandar memiliki kekayaan tradisi yang beragam, mulai dari Tari Pattudu, Tari Bamba Manurung, hingga berbagai kesenian lainnya yang mencerminkan nilai kebersamaan, penghormatan, dan identitas masyarakat Mandar.",
                        "16:39",
                      ),

                      _buildUserMessage(
                        "Oh gitu ya, Pattudu artinya apa sih?",
                        "16:40",
                      ),

                      _buildBotMessage(
                        "Pattudu berarti tarian tradisional Mandar yang menggambarkan keanggunan, kebersamaan, dan penghormatan budaya.",
                        "16:41",
                      ),
                    ],
                  ),
                ),
              ),

              // Bar Input Chat di Bawah
              Container(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                color: const Color(0xFFFCF5EE),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildChip("Apa makanan khas Mandar?"),
                          const SizedBox(width: 8),
                          _buildChip("Ceritakan aku tentang..."),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(color: const Color(0xFFEAEAEA)),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.03),
                                  blurRadius: 5,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              children: const [
                                Expanded(
                                  child: TextField(
                                    style: TextStyle(fontSize: 16),
                                    decoration: InputDecoration(
                                      hintText: "Ketik pesan..",
                                      border: InputBorder.none,
                                      hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
                                    ),
                                  ),
                                ),
                                Icon(Icons.photo_outlined, color: Colors.grey, size: 22),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatLiveScreen()),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF007979),
                            ),
                            child: const Icon(Icons.graphic_eq, color: Colors.white, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Desain Pesan Bot
  Widget _buildBotMessage(String text, String time, {bool isFirst = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Frame Lingkaran Avatar
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFFFEED0),
            ),
            child: ClipOval(
              child: Transform.translate(
                offset: const Offset(0, 2),
                child: Transform.scale(
                  scale: 1,
                  child: Image.asset(
                    'assets/maskot/mascot_mandar.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isFirst ? Colors.white.withOpacity(0.85) : Colors.white,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(0),
                  topRight: Radius.circular(16),
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
                border: Border.all(color: const Color(0xFFEAEAEA)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    text,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      time,
                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!isFirst) ...[
            const SizedBox(width: 8),
            const Padding(
              padding: EdgeInsets.only(top: 8.0),
              child: Icon(Icons.menu_book_outlined, size: 20, color: Colors.grey),
            ),
          ] else ...[
            const SizedBox(width: 28),
          ],
        ],
      ),
    );
  }

  // Desain Pesan Pengguna
  Widget _buildUserMessage(String text, String time) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 64, right: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Flexible(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 280),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFE0F2F1),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(0),
                  ),
                  border: Border.all(color: const Color(0xFFEAEAEA)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      text,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          time,
                          style: TextStyle(fontSize: 10, color: Colors.grey[700]),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.done_all, size: 14, color: Colors.black54),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFEAEAEA)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    );
  }
}