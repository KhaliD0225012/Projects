import 'package:flutter/material.dart';
import 'chat_screen.dart';
import 'chat_bali_screen.dart';

class MapCultureScreen extends StatefulWidget {
  const MapCultureScreen({super.key});

  @override
  State<MapCultureScreen> createState() => _MapCultureScreenState();
}

class _MapCultureScreenState extends State<MapCultureScreen> {
  final TransformationController _transformationController = TransformationController();

  final double _mapWidth = 1920.0;
  final double _mapHeight = 1080.0;

  double _currentScale = 1.0;

  @override
  void initState() {
    super.initState();
    _transformationController.addListener(_onTransformationChanged);

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _centerMap();
    });
  }

  void _onTransformationChanged() {
    final double scale = _transformationController.value.getMaxScaleOnAxis();
    if (_currentScale != scale) {
      setState(() {
        _currentScale = scale;
      });
    }
  }

  void _centerMap() {
    final Size screenSize = MediaQuery.of(context).size;

    final double xOffset = (screenSize.width - _mapWidth) / 2;
    final double yOffset = (screenSize.height - _mapHeight) / 2;

    _transformationController.value = Matrix4.identity()
      ..translate(xOffset, yOffset);
  }

  @override
  void dispose() {
    _transformationController.removeListener(_onTransformationChanged);
    _transformationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const double baseOuterSize = 22.0;
    const double baseInnerSize = 12.0;

    return Scaffold(
      backgroundColor: const Color(0xFF81D4FA),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 18),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text(
              "Peta Indonesia",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2D2D2D),
              ),
            ),
            SizedBox(height: 2),
            Text(
              "Pilih budaya",
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.black87),
            onPressed: () {},
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            children: [
              SizedBox(
                width: constraints.maxWidth,
                height: constraints.maxHeight,
                child: InteractiveViewer(
                  transformationController: _transformationController,
                  constrained: false,
                  boundaryMargin: EdgeInsets.symmetric(
                    horizontal: constraints.maxWidth,
                    vertical: constraints.maxHeight,
                  ),
                  minScale: 0.5,
                  maxScale: 4.0,
                  child: SizedBox(
                    width: _mapWidth,
                    height: _mapHeight,
                    child: Stack(
                      children: [
                        // Gambar Peta Utama
                        Image.asset(
                          'assets/images/map.png',
                          width: _mapWidth,
                          height: _mapHeight,
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) => Image.asset(
                            'assets/images/map.jpg',
                            width: _mapWidth,
                            height: _mapHeight,
                            fit: BoxFit.cover,
                          ),
                        ),

                        // Titik Biru Posisi Pengguna (Sulawesi Barat)
                        Positioned(
                          top: _mapHeight * 0.52 - ((baseOuterSize / _currentScale) / 2),
                          left: _mapWidth * 0.47 - ((baseOuterSize / _currentScale) / 2),
                          child: Container(
                            width: baseOuterSize / _currentScale,
                            height: baseOuterSize / _currentScale,
                            decoration: BoxDecoration(
                              color: const Color(0xFF2196F3).withOpacity(0.3),
                              shape: BoxShape.circle,
                            ),
                            child: Center(
                              child: Container(
                                width: baseInnerSize / _currentScale,
                                height: baseInnerSize / _currentScale,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF1E88E5),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: Colors.white,
                                    width: 2 / _currentScale,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 4 / _currentScale,
                                      offset: Offset(0, 2 / _currentScale),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),

                        // --- PIN-PIN BUDAYA INDONESIA ---

                        // Mandar (Sulawesi Barat) -> Menuju ChatScreen
                        _buildCulturePin(
                          name: "Mandar",
                          imageName: "mandar",
                          top: _mapHeight * 0.507,
                          left: _mapWidth * 0.465,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatScreen()),
                            );
                          },
                        ),

                        // Toraja (Sulawesi Selatan)
                        _buildCulturePin(
                          name: "Toraja",
                          imageName: "toraja",
                          top: _mapHeight * 0.54,
                          left: _mapWidth * 0.475,
                        ),

                        // Batak (Sumatera Utara)
                        _buildCulturePin(
                          name: "Batak",
                          imageName: "batak",
                          top: _mapHeight * 0.30,
                          left: _mapWidth * 0.123,
                        ),

                        // Padang (Sumatera Barat)
                        _buildCulturePin(
                          name: "Padang",
                          imageName: "padang",
                          top: _mapHeight * 0.40,
                          left: _mapWidth * 0.15,
                        ),

                        // Betawi (DKI Jakarta)
                        _buildCulturePin(
                          name: "Betawi",
                          imageName: "betawi",
                          top: _mapHeight * 0.55,
                          left: _mapWidth * 0.255,
                        ),

                        // Sunda (Jawa Barat)
                        _buildCulturePin(
                          name: "Sunda",
                          imageName: "sunda",
                          top: _mapHeight * 0.57,
                          left: _mapWidth * 0.27,
                        ),

                        // Jawa (Jawa Tengah/Timur)
                        _buildCulturePin(
                          name: "Jawa",
                          imageName: "jawa",
                          top: _mapHeight * 0.58,
                          left: _mapWidth * 0.32,
                        ),

                        // Bali (Pulau Bali) -> Menuju ChatBaliScreen
                        _buildCulturePin(
                          name: "Bali",
                          imageName: "bali",
                          top: _mapHeight * 0.614,
                          left: _mapWidth * 0.392,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatBaliScreen()),
                            );
                          },
                        ),

                        // Dayak (Kalimantan Tengah)
                        _buildCulturePin(
                          name: "Dayak",
                          imageName: "dayak",
                          top: _mapHeight * 0.45,
                          left: _mapWidth * 0.38,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              Positioned(
                right: 20,
                bottom: 30,
                child: FloatingActionButton(
                  onPressed: _centerMap,
                  backgroundColor: const Color(0xFF007979),
                  elevation: 4,
                  child: const Icon(Icons.my_location, color: Colors.white),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // Widget Pembantu Pin Budaya
  Widget _buildCulturePin({
    required String name,
    required String imageName,
    required double top,
    required double left,
    VoidCallback? onTap,
  }) {
    final double avatarSize = 48.0 / _currentScale;
    final double dotSize = 10.0 / _currentScale;
    final double fontSizeName = 16.0 / _currentScale;
    final double fontSizeSub = 11.0 / _currentScale;

    return Positioned(
      top: top,
      left: left,
      child: GestureDetector(
        onTap: onTap,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            // Kolom Kiri: Avatar dan Titik Putih Persis di Bawah Avatar
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Avatar Lingkaran
                Container(
                  width: avatarSize,
                  height: avatarSize,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: Border.all(color: Colors.white, width: 2.5 / _currentScale),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 4 / _currentScale,
                        offset: Offset(0, 2 / _currentScale),
                      ),
                    ],
                  ),
                  child: ClipOval(
                    child: Image.asset(
                      'assets/pin_avatar/jel_$imageName.png',
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: Colors.grey.shade300,
                        child: Icon(Icons.person, size: 24 / _currentScale, color: Colors.grey),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 4 / _currentScale),

                // Titik Putih Penunjuk Tepat di Bawah Avatar
                Container(
                  width: dotSize,
                  height: dotSize,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 3 / _currentScale,
                        offset: Offset(0, 1 / _currentScale),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(width: 8 / _currentScale),

            // Kolom Kanan: Teks Nama & Subtitle
            Padding(
              padding: EdgeInsets.only(top: 4.0 / _currentScale),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: fontSizeName,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                      shadows: const [
                        Shadow(offset: Offset(1, 1), blurRadius: 3, color: Colors.white),
                        Shadow(offset: Offset(-1, -1), blurRadius: 3, color: Colors.white),
                        Shadow(offset: Offset(1, -1), blurRadius: 3, color: Colors.white),
                        Shadow(offset: Offset(-1, 1), blurRadius: 3, color: Colors.white),
                      ],
                    ),
                  ),
                  Text(
                    "Lihat info pariwisata",
                    style: TextStyle(
                      fontSize: fontSizeSub,
                      fontWeight: FontWeight.w600,
                      color: Colors.black87,
                      shadows: const [
                        Shadow(offset: Offset(1, 1), blurRadius: 2, color: Colors.white),
                        Shadow(offset: Offset(-1, -1), blurRadius: 2, color: Colors.white),
                        Shadow(offset: Offset(1, -1), blurRadius: 2, color: Colors.white),
                        Shadow(offset: Offset(-1, 1), blurRadius: 2, color: Colors.white),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}