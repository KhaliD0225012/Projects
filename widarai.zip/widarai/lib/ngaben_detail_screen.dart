import 'package:flutter/material.dart';

class NgabenDetailScreen extends StatefulWidget {
  const NgabenDetailScreen({super.key});

  @override
  State<NgabenDetailScreen> createState() => _NgabenDetailScreenState();
}

class _NgabenDetailScreenState extends State<NgabenDetailScreen> {
  bool _isLiked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        centerTitle: true,
        toolbarHeight: 80, // <-- Menaikkan tinggi AppBar
        leading: Padding(
          padding: const EdgeInsets.only(top: 12.0), // Memberikan jarak dari atas untuk tombol kembali
          child: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 18),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0), // <-- Memberikan jarak antara title dan bagian atas layar
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Mengenal Ngaben Bali, Lebi...",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D2D2D),
                ),
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              const Text(
                "Budaya Bali",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(top: 12.0), // Memberikan jarak dari atas untuk tombol suka
            child: IconButton(
              icon: Icon(
                _isLiked ? Icons.favorite : Icons.favorite_border,
                color: _isLiked ? Colors.red : Colors.black87,
                size: 24,
              ),
              onPressed: () {
                setState(() {
                  _isLiked = !_isLiked;
                });
              },
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(
                height: 200,
                width: double.infinity,
                child: Image.asset(
                  'assets/artikel/ngaben.png',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    color: Colors.grey.shade200,
                    child: const Icon(Icons.image, size: 50, color: Colors.grey),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Mengenal Ngaben Bali, Lebih dari Sekadar Upacara Kremasi",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2D2D2D),
                height: 1.3,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Budaya Bali • detikNews",
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Ngaben adalah salah satu upacara adat dan keagamaan masyarakat Hindu di Bali yang dilakukan sebagai bentuk penghormatan kepada seseorang yang telah meninggal. Upacara ini berkaitan dengan kepercayaan Hindu mengenai perjalanan roh setelah kematian dan proses kembalinya tubuh manusia kepada alam. Dalam kepercayaan Hindu Bali, tubuh manusia terdiri dari unsur jasmani dan rohani. Ketika seseorang meninggal, tubuh fisiknya tidak lagi digunakan, sedangkan atman atau jiwa dipercaya melanjutkan perjalanan spiritualnya.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Ngaben sering dikenal sebagai upacara kremasi karena terdapat proses pembakaran jenazah. Namun, makna Ngaben tidak hanya terletak pada pembakaran tersebut. Api dalam upacara memiliki makna sebagai unsur penyucian dan pelepasan. Melalui proses tersebut, unsur jasmani dikembalikan kepada alam, sementara keluarga melaksanakan doa dan ritual untuk mendukung perjalanan spiritual orang yang telah meninggal.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Pelaksanaan Ngaben membutuhkan berbagai persiapan dan biasanya melibatkan keluarga serta masyarakat sekitar. Salah satu perlengkapan yang terkenal adalah bade, yaitu bangunan berbentuk menara yang digunakan untuk membawa jenazah menuju tempat upacara. Selain bade, terdapat patulangan, yaitu wadah yang digunakan dalam proses kremasi. Bentuk dan hiasannya dapat berbeda sesuai dengan tradisi dan ketentuan adat masing-masing daerah.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Sebelum proses kremasi, dilakukan berbagai ritual seperti persembahyangan dan penyucian. Setelah itu, jenazah dibawa menuju tempat kremasi untuk menjalani proses pembakaran. Pelaksanaan Ngaben tidak selalu sama di setiap daerah karena dapat dipengaruhi oleh adat setempat, kondisi keluarga, serta kemampuan dalam menyelenggarakan upacara.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Ngaben juga memiliki nilai sosial dan budaya yang kuat. Keluarga biasanya dibantu oleh masyarakat dalam mempersiapkan berbagai kebutuhan upacara. Hal ini menunjukkan semangat gotong royong, kebersamaan, dan solidaritas masyarakat Bali. Selain itu, Ngaben menjadi bagian dari pelestarian budaya karena di dalamnya terdapat berbagai unsur seperti pakaian adat, musik tradisional, seni ukir, arsitektur, sesajen, dan tata cara keagamaan.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Bagi masyarakat Hindu Bali, kematian dipandang sebagai bagian dari perjalanan kehidupan dan spiritual manusia. Karena itu, Ngaben memiliki makna penting sebagai bentuk penghormatan terakhir sekaligus ritual untuk membantu proses pelepasan dan perjalanan spiritual orang yang telah meninggal.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}