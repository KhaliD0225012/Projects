import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'register_screen.dart';
import 'components.dart';
import 'welcome_screen.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Tombol kembali di pojok kiri atas telah dihapus
              const SizedBox(height: 12),

              const Text(
                "Selamat datang kembali! 👋",
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900, // Dipertebal (Bold)
                  color: Color(0xFF2D2D2D),
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(height: 12),

              const Text(
                "Masuk untuk melanjutkan\nperjalanan budaya mu",
                style: TextStyle(
                  fontSize: 17,
                  color: Color(0xFF555555), // Warna subtitle lebih gelap
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 40),

              const CustomTextField(
                label: "Email",
                hint: "contoh@email.com",
              ),

              const SizedBox(height: 20),

              const CustomTextField(
                label: "Kata Sandi",
                hint: "Masukkan kata sandi",
                isPassword: true,
              ),

              const SizedBox(height: 12),
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  "Lupa Sandi?",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF007979),
                  ),
                ),
              ),

              const SizedBox(height: 20),

              Container(
                width: double.infinity,
                height: 56,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.06),
                      blurRadius: 0,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const WelcomeScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF007979),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  child: const Text(
                    "Masuk",
                    style: TextStyle(
                      fontSize: 19,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 32),
              const DividerWithText(text: "atau masuk dengan"),
              const SizedBox(height: 32),

              const GoogleButton(),

              const Spacer(),

              Center(
                child: Text.rich(
                  TextSpan(
                    text: "Belum punya akun? ",
                    style: const TextStyle(color: Color(0xFF757575), fontSize: 16),
                    children: [
                      TextSpan(
                        text: "Daftar di sini",
                        style: const TextStyle(
                          color: Color(0xFF007979),
                          fontWeight: FontWeight.w900, // Dipertebal (Bold)
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const RegisterScreen()),
                            );
                          },
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}