import 'package:flutter/material.dart';
import 'onboarding_screen.dart';
import 'main_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Widarai App',
      theme: ThemeData(
        fontFamily: 'DM Sans',
        scaffoldBackgroundColor: const Color(0xFFFCF5EE),
      ),
      home: const OnboardingScreen(),
      routes: {
        '/main': (context) => const MainScreen(),
      },
    );
  }
}