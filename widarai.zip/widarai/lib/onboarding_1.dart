import 'package:flutter/material.dart';

class Onboarding1 extends StatelessWidget {
  const Onboarding1({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
      child: Column(
        children: [
          const SizedBox(height: 80),
          SizedBox(
            width: 300,
            child: Column(
              children: const [
                Text(
                  "Selamat datang di",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF2D2D2D), height: 1.2, letterSpacing: -0.5),
                ),
                Text(
                  "WIDARAI",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Color(0xFF007979), height: 1.2, letterSpacing: -0.5),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Container(width: 72, height: 2, color: const Color(0xFF007979).withOpacity(0.4)),
          const SizedBox(height: 24),
          const SizedBox(
            width: 300,
            child: Text(
              "Teman pintarmu untuk mengenal budaya Indonesia dan menemukan pengalaman wisata yang bermakna!",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.normal, color: Color(0xFF666666), height: 1.4),
            ),
          ),
          const SizedBox(height: 20),

          // Gambar Maskot dari Assets
          Expanded(
            child: Center(
              child: Image.asset(
                'assets/onboarding/mascot_1.png',
                width: 284,
                fit: BoxFit.contain,
              ),
            ),
          ),
        ],
      ),
    );
  }
}