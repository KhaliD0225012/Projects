import 'package:flutter/material.dart';

class SayyangPattuduDetailScreen extends StatefulWidget {
  const SayyangPattuduDetailScreen({super.key});

  @override
  State<SayyangPattuduDetailScreen> createState() => _SayyangPattuduDetailScreenState();
}

class _SayyangPattuduDetailScreenState extends State<SayyangPattuduDetailScreen> {
  bool _isLiked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        centerTitle: true,
        toolbarHeight: 80, // <-- Menaikkan tinggi AppBar
        leading: Padding(
          padding: const EdgeInsets.only(top: 12.0), // Memberikan jarak dari atas untuk tombol kembali
          child: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new, color: Colors.black87, size: 18),
            onPressed: () => Navigator.pop(context),
          ),
        ),
        title: Padding(
          padding: const EdgeInsets.only(top: 12.0), // <-- Memberikan jarak antara title dan bagian atas layar
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Text(
                "Sayyang Pattudu, Pesona Ku...",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D2D2D),
                ),
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              const Text(
                "Budaya Mandar",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(top: 12.0), // Memberikan jarak dari atas untuk tombol suka
            child: IconButton(
              icon: Icon(
                _isLiked ? Icons.favorite : Icons.favorite_border,
                color: _isLiked ? Colors.red : Colors.black87,
                size: 24,
              ),
              onPressed: () {
                setState(() {
                  _isLiked = !_isLiked;
                });
              },
            ),
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SizedBox(
                height: 200,
                width: double.infinity,
                child: Image.asset(
                  'assets/artikel/pattudu.png',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) => Container(
                    color: Colors.grey.shade200,
                    child: const Icon(Icons.image, size: 50, color: Colors.grey),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Sayyang Pattudu, Pesona Kuda Menari dari Tanah Mandar",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF2D2D2D),
                height: 1.3,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              "Budaya Mandar • CNN Indonesia",
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              "Indonesia merupakan negara yang memiliki kekayaan budaya yang sangat beragam. Salah satu warisan budaya yang menarik berasal dari masyarakat Mandar, Sulawesi Barat, yaitu Sayyang Pattudu. Tradisi ini dikenal sebagai pertunjukan kuda yang ditunggangi sambil mengikuti irama musik tradisional dan gerakan yang khas. Sayyang Pattudu bukan sekadar hiburan, tetapi juga menjadi bagian penting dari kehidupan dan identitas masyarakat Mandar.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Secara harfiah, sayyang berarti kuda, sedangkan pattudu berarti penari. Dengan demikian, Sayyang Pattudu dapat dimaknai sebagai kuda yang menari. Dalam pelaksanaannya, seekor kuda dihias dengan berbagai ornamen dan ditunggangi oleh seorang anak perempuan atau perempuan yang mengenakan pakaian adat Mandar. Kuda kemudian diarahkan untuk bergerak mengikuti irama musik yang dimainkan oleh para pemusik.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Tradisi Sayyang Pattudu memiliki hubungan yang erat dengan masyarakat Mandar, terutama dalam perayaan Maulid Nabi Muhammad saw. Dalam tradisi masyarakat setempat, Sayyang Pattudu sering menjadi bagian dari rangkaian perayaan tersebut. Anak-anak yang telah menyelesaikan pembacaan Al-Qur'an atau menunjukkan pencapaian dalam pendidikan keagamaan dapat diarak menggunakan kuda sebagai bentuk penghargaan dan kebanggaan keluarga.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Pertunjukan ini semakin meriah dengan hadirnya musik tradisional dan lantunan kalindaqdaq, yaitu sastra lisan khas Mandar yang disampaikan dalam bentuk syair. Kalindaqdaq dapat berisi nasihat, pujian, ungkapan perasaan, hingga pesan-pesan kehidupan. Perpaduan antara kuda, pakaian adat, musik, dan syair menjadikan Sayyang Pattudu sebagai pertunjukan budaya yang memiliki daya tarik tersendiri.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Di balik kemeriahannya, Sayyang Pattudu mengandung nilai-nilai kehidupan yang penting. Tradisi ini mengajarkan kebersamaan, penghargaan terhadap pendidikan, penghormatan terhadap budaya leluhur, serta rasa syukur kepada Tuhan. Pelaksanaannya juga mempererat hubungan antarkeluarga dan masyarakat karena melibatkan banyak orang dalam persiapan maupun pelaksanaannya.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Seiring perkembangan zaman, Sayyang Pattudu tidak hanya dikenal di lingkungan masyarakat Mandar, tetapi juga semakin sering ditampilkan dalam berbagai kegiatan kebudayaan dan festival. Hal tersebut menjadi salah satu cara untuk memperkenalkan budaya Mandar kepada masyarakat luas, khususnya generasi muda.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              "Oleh karena itu, Sayyang Pattudu perlu terus dilestarikan. Generasi muda memiliki peran penting dalam mengenal, mempelajari, dan memperkenalkan tradisi ini kepada orang lain. Dengan menjaga keberlangsungannya, masyarakat tidak hanya mempertahankan sebuah pertunjukan tradisional, tetapi juga menjaga identitas dan warisan budaya Mandar agar tetap hidup dari generasi ke generasi.",
              textAlign: TextAlign.justify,
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF2D2D2D),
                height: 1.6,
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}