import 'package:flutter/material.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final TextEditingController _nameController = TextEditingController(text: "Budi Santoso");
  final TextEditingController _bioController = TextEditingController(text: "Aku cinta Indonesia");

  // State untuk melacak panjang teks secara real-time
  late int _nameLength;
  late int _bioLength;

  @override
  void initState() {
    super.initState();
    _nameLength = _nameController.text.length;
    _bioLength = _bioController.text.length;

    // Listener untuk memperbarui counter saat teks berubah
    _nameController.addListener(() {
      setState(() {
        _nameLength = _nameController.text.length;
      });
    });

    _bioController.addListener(() {
      setState(() {
        _bioLength = _bioController.text.length;
      });
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    super.dispose();
  }

  // Fungsi untuk menampilkan Bottom Sheet opsi foto profil
  void _showImageSourceBottomSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Ubah Foto Profil",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D2D2D),
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF007979).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.camera_alt, color: Color(0xFF007979)),
                ),
                title: const Text(
                  "Ambil Foto",
                  style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF2D2D2D)),
                ),
                subtitle: const Text("Gunakan kamera perangkat", style: TextStyle(fontSize: 12, color: Colors.grey)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
              const Divider(color: Color(0xFFEAEAEA)),
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF007979).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.photo_library, color: Color(0xFF007979)),
                ),
                title: const Text(
                  "Pilih dari Galeri",
                  style: TextStyle(fontWeight: FontWeight.w600, color: Color(0xFF2D2D2D)),
                ),
                subtitle: const Text("Ambil dari penyimpanan galeri", style: TextStyle(fontSize: 12, color: Colors.grey)),
                onTap: () {
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    bool isNameExceeded = _nameLength > 20;
    bool isBioExceeded = _bioLength > 50;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFCF5EE),
        elevation: 0,
        scrolledUnderElevation: 0.0,
        title: const Text(
          "Edit Profil",
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF2D2D2D),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Color(0xFF2D2D2D)),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
        child: Column(
          children: [
            Center(
              child: Stack(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: const DecorationImage(
                        image: AssetImage('assets/riwayat/profil.png'),
                        fit: BoxFit.cover,
                      ),
                      border: Border.all(color: const Color(0xFFEAEAEA), width: 2),
                    ),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: GestureDetector(
                      onTap: _showImageSourceBottomSheet,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: const BoxDecoration(
                          color: Color(0xFF007979),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.camera_alt,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Nama Lengkap Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Nama Lengkap",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2D2D2D),
                  ),
                ),
                Text(
                  "$_nameLength/20",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isNameExceeded ? const Color(0xFFD32F2F) : Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isNameExceeded ? const Color(0xFFD32F2F) : const Color(0xFFEAEAEA)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isNameExceeded ? const Color(0xFFD32F2F) : const Color(0xFFEAEAEA)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isNameExceeded ? const Color(0xFFD32F2F) : const Color(0xFF007979)),
                ),
              ),
            ),
            if (isNameExceeded)
              const Padding(
                padding: EdgeInsets.only(top: 6.0, left: 4.0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Nama lengkap melebihi batas maksimal 20 karakter",
                    style: TextStyle(fontSize: 11, color: Color(0xFFD32F2F), fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            const SizedBox(height: 20),

            // Bio / Status Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Bio / Status",
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF2D2D2D),
                  ),
                ),
                Text(
                  "$_bioLength/50",
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isBioExceeded ? const Color(0xFFD32F2F) : Colors.grey,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _bioController,
              maxLines: 2,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.all(16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isBioExceeded ? const Color(0xFFD32F2F) : const Color(0xFFEAEAEA)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isBioExceeded ? const Color(0xFFD32F2F) : const Color(0xFFEAEAEA)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: isBioExceeded ? const Color(0xFFD32F2F) : const Color(0xFF007979)),
                ),
              ),
            ),
            if (isBioExceeded)
              const Padding(
                padding: EdgeInsets.only(top: 6.0, left: 4.0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Bio/status melebihi batas maksimal 50 karakter",
                    style: TextStyle(fontSize: 11, color: Color(0xFFD32F2F), fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            const SizedBox(height: 40),

            // Tombol Simpan
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: (isNameExceeded || isBioExceeded) ? Colors.grey.shade400 : const Color(0xFF007979),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 0,
                ),
                onPressed: (isNameExceeded || isBioExceeded)
                    ? null // Nonaktifkan tombol jika ada yang melebihi batas
                    : () {
                  Navigator.pop(context);
                },
                child: const Text(
                  "Simpan Perubahan",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}