import 'package:flutter/material.dart';
import 'chat_bali_live_screen.dart'; // Tambahkan import ini

class ChatBaliActiveScreen extends StatefulWidget {
  const ChatBaliActiveScreen({super.key});

  @override
  State<ChatBaliActiveScreen> createState() => _ChatBaliActiveScreenState();
}

class _ChatBaliActiveScreenState extends State<ChatBaliActiveScreen> {
  bool _isLiked = false;

  // Fungsi untuk memperbesar gambar dengan latar belakang gelap
  void _showFullScreenImage(BuildContext context, String imagePath) {
    Navigator.push(
      context,
      PageRouteBuilder(
        opaque: false,
        pageBuilder: (BuildContext context, _, __) {
          return Scaffold(
            backgroundColor: Colors.black.withOpacity(0.85),
            body: GestureDetector(
              onTap: () => Navigator.pop(context),
              child: Center(
                child: Hero(
                  tag: imagePath,
                  child: InteractiveViewer(
                    child: Image.asset(imagePath),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final double screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFFFCF5EE),
      extendBodyBehindAppBar: true,
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(80.0),
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
          toolbarHeight: 80.0,
          titleSpacing: 0,
          leading: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, size: 18, color: Colors.black87),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          title: Padding(
            padding: const EdgeInsets.only(top: 12.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Text(
                  "Budaya Bali",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Colors.black87),
                ),
                SizedBox(height: 2),
                Text(
                  "Pulau dewata yang memiliki b..",
                  style: TextStyle(fontSize: 13, color: Colors.grey),
                ),
              ],
            ),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(top: 12.0, right: 8.0),
              child: IconButton(
                icon: Icon(
                  _isLiked ? Icons.favorite : Icons.favorite_border,
                  color: Colors.red,
                  size: 24,
                ),
                onPressed: () {
                  setState(() {
                    _isLiked = !_isLiked;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(_isLiked ? "Ditambahkan ke favorit!" : "Dihapus dari favorit"),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          // 1. Gambar Background (Tinggi 2/5 layar = 40%)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: screenHeight * 0.4,
            child: Stack(
              fit: StackFit.expand,
              children: [
                Image.asset(
                  'assets/background/chat_background_2.jpg',
                  fit: BoxFit.fitWidth,
                  alignment: Alignment.bottomCenter,
                ),
                // Efek Pudar ke bawah
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        const Color(0xFFFCF5EE).withOpacity(0.0),
                        const Color(0xFFFCF5EE),
                      ],
                      stops: const [0.3, 1.0],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // 2. Daftar Pesan Chat dan Input Bar
          Column(
            children: [
              Expanded(
                child: ShaderMask(
                  shaderCallback: (Rect bounds) {
                    return const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.black, Colors.black],
                      stops: [0.0, 0.48, 1.0],
                    ).createShader(bounds);
                  },
                  blendMode: BlendMode.dstIn,
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    children: [
                      const SizedBox(height: 140),

                      // Pesan Pertama (List Tarian)
                      _buildBotMessage(
                        "• Tari Pendet\n• Tari Legong\n• Tari Barong\n• Tari Baris\n• Tari Janger\n• Tari Topeng\n• Tari Gambuh",
                        "12:53",
                        isFirst: true,
                      ),

                      // Pertanyaan Pengguna
                      _buildUserMessage(
                        "Upacara Ngaben di tradisi Bali itu apa sih?",
                        "12:56",
                      ),

                      // Penjelasan Bot
                      _buildBotMessage(
                        "Upacara kremasi dalam tradisi Hindu Bali yang berkaitan dengan penghormatan kepada orang yang telah meninggal dan perjalanan spiritualnya.",
                        "12:56",
                      ),

                      // Pesan Gambar (Ngaben) yang bisa di-tap
                      _buildBotImageMessage(
                        "assets/images/ngaben.png",
                        context,
                      ),
                    ],
                  ),
                ),
              ),

              // Bar Input Chat di Bawah
              Container(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                color: const Color(0xFFFCF5EE),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _buildChip("Bagaimana proses Ngaben?"),
                          const SizedBox(width: 8),
                          _buildChip("Apa ciri khas d"),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(28),
                              border: Border.all(color: const Color(0xFFEAEAEA)),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.03),
                                  blurRadius: 5,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              children: const [
                                Expanded(
                                  child: TextField(
                                    style: TextStyle(fontSize: 16),
                                    decoration: InputDecoration(
                                      hintText: "Ketik pesan..",
                                      border: InputBorder.none,
                                      hintStyle: TextStyle(fontSize: 16, color: Colors.grey),
                                    ),
                                  ),
                                ),
                                Icon(Icons.mic_none, color: Colors.grey, size: 24),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),

                        // TOMBOL MENUJU LIVE CHAT BALI
                        GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const ChatBaliLiveScreen()),
                            );
                          },
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Color(0xFF007979),
                            ),
                            child: const Icon(Icons.graphic_eq, color: Colors.white, size: 22),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // Desain Pesan Teks Bot
  Widget _buildBotMessage(String text, String time, {bool isFirst = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!isFirst)
            Container(
              width: 46,
              height: 46,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFFFFEED0),
              ),
              child: ClipOval(
                child: Transform.translate(
                  offset: const Offset(0, 2),
                  child: Transform.scale(
                    scale: 1,
                    child: Image.asset(
                      'assets/maskot/mascot_bali.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            )
          else
            const SizedBox(width: 46),

          const SizedBox(width: 8),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isFirst ? Colors.white.withOpacity(0.85) : Colors.white,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(0),
                  topRight: Radius.circular(16),
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
                border: Border.all(color: const Color(0xFFEAEAEA)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    text,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                      height: 1.4,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Align(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      time,
                      style: const TextStyle(fontSize: 10, color: Colors.grey),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!isFirst) ...[
            const SizedBox(width: 8),
            const Padding(
              padding: EdgeInsets.only(top: 8.0),
              child: Icon(Icons.menu_book_outlined, size: 20, color: Colors.grey),
            ),
          ] else ...[
            const SizedBox(width: 28),
          ],
        ],
      ),
    );
  }

  // Desain Pesan Gambar Bot
  Widget _buildBotImageMessage(String imagePath, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 16, right: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(width: 46),
          const SizedBox(width: 8),
          Expanded(
            child: GestureDetector(
              onTap: () => _showFullScreenImage(context, imagePath),
              child: Hero(
                tag: imagePath,
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFEAEAEA)),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      imagePath,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 28),
        ],
      ),
    );
  }

  // Desain Pesan Pengguna
  Widget _buildUserMessage(String text, String time) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16, left: 64, right: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Flexible(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 280),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFE0F2F1),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(16),
                    topRight: Radius.circular(16),
                    bottomLeft: Radius.circular(16),
                    bottomRight: Radius.circular(0),
                  ),
                  border: Border.all(color: const Color(0xFFEAEAEA)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      text,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Colors.black87,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          time,
                          style: TextStyle(fontSize: 10, color: Colors.grey[700]),
                        ),
                        const SizedBox(width: 4),
                        const Icon(Icons.done_all, size: 14, color: Colors.black54),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: const Color(0xFFEAEAEA)),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.black87,
        ),
      ),
    );
  }
}