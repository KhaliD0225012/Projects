package com.example.widarai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
